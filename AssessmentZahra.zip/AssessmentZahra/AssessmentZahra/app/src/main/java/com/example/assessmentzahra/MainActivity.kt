package com.example.assessmentzahra

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.assessmentzahra.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupSemesterDropdown()
        setupYesNoDropdowns()
        setupSubmitButton()
    }

    private fun setupSemesterDropdown() {
        val semesterItems = resources.getStringArray(R.array.semester_options)
        val semesterAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, semesterItems)
        (binding.spinnerSemester as? AutoCompleteTextView)?.setAdapter(semesterAdapter)
    }    private fun setupYesNoDropdowns() {
        val yesNoItems = resources.getStringArray(R.array.yes_no_options)
        val yesNoAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, yesNoItems)

        val internetItems = resources.getStringArray(R.array.internet_options)
        val internetAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, internetItems)

        (binding.spinnerInternet as? AutoCompleteTextView)?.setAdapter(internetAdapter)
        (binding.spinnerInstallStudio as? AutoCompleteTextView)?.setAdapter(yesNoAdapter)
    }

    private fun setupSubmitButton() {
        binding.btnSubmit.setOnClickListener {
            if (validateForm()) {
                val assessmentData = createAssessmentDataFromInputs()
                navigateToResultActivity(assessmentData)
            }
        }
    }

    private fun validateForm(): Boolean {
        // Required fields validation
        if (binding.etNim.text.toString().isEmpty()) {
            showToast("NIM harus diisi")
            return false
        }

        if (binding.etNama.text.toString().isEmpty()) {
            showToast("Nama harus diisi")
            return false
        }

        if (binding.spinnerSemester.text.toString().isEmpty()) {
            showToast("Semester harus dipilih")
            return false
        }

        // Add more validations as needed for other fields

        return true
    }    private fun createAssessmentDataFromInputs(): AssessmentData {
        return AssessmentData(
            nim = binding.etNim.text.toString(),
            nama = binding.etNama.text.toString(),
            semester = binding.spinnerSemester.text.toString(),
            deviceCoding = binding.etDeviceCoding.text.toString(),
            osDevice = binding.etOsDevice.text.toString(),
            osVersion = binding.etOsVersion.text.toString(),
            ram = binding.etRam.text.toString(),
            cpu = binding.etCpu.text.toString(),
            deployment = binding.etDeployment.text.toString(),
            merkHp = binding.etMerkHp.text.toString(),
            osHp = binding.etOsHp.text.toString(),
            ukuranHp = binding.etUkuranHp.text.toString(),
            internet = binding.spinnerInternet.text.toString(),
            installStudio = binding.spinnerInstallStudio.text.toString(),
            studioVersion = binding.etStudioVersion.text.toString()
        )
    }

    private fun navigateToResultActivity(data: AssessmentData) {
        val intent = Intent(this, ResultActivity::class.java).apply {
            putExtra(EXTRA_ASSESSMENT_DATA, data)
        }
        startActivity(intent)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        const val EXTRA_ASSESSMENT_DATA = "extra_assessment_data"
    }
}

