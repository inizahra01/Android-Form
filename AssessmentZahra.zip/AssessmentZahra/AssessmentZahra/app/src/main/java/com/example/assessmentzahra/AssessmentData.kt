package com.example.assessmentzahra

import java.io.Serializable

data class AssessmentData(
    val nim: String,
    val nama: String,
    val semester: String,
    val deviceCoding: String,
    val osDevice: String,
    val osVersion: String,
    val ram: String,
    val cpu: String,
    val deployment: String,
    val merkHp: String,
    val osHp: String,
    val ukuranHp: String,
    val internet: String,
    val installStudio: String,
    val studioVersion: String
) : Serializable