package com.example.assessmentzahra

import android.app.Dialog
import android.os.Bundle
import android.view.Window
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.assessmentzahra.databinding.ActivityResultBinding

class ResultActivity : AppCompatActivity() {

    private lateinit var binding: ActivityResultBinding
    private var assessmentData: AssessmentData? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Get data from intent
        assessmentData = intent.getSerializableExtra(MainActivity.EXTRA_ASSESSMENT_DATA) as? AssessmentData

        // Display data
        displayAssessmentData()

        // Setup developer info button
        binding.btnDeveloperInfo.setOnClickListener {
            showDeveloperInfoDialog()
        }
    }    private fun displayAssessmentData() {
        assessmentData?.let { data ->
            // Fill in all the TextView fields with the data
            binding.apply {
                tvNim.text = data.nim
                tvNama.text = data.nama
                tvSemester.text = data.semester
                tvDeviceCoding.text = data.deviceCoding
                tvOsDevice.text = data.osDevice
                tvOsVersion.text = data.osVersion
                tvRam.text = data.ram
                tvCpu.text = data.cpu
                tvDeployment.text = data.deployment
                tvMerkHp.text = data.merkHp
                tvOsHp.text = data.osHp
                tvUkuranHp.text = data.ukuranHp
                tvInternet.text = data.internet
                tvInstallStudio.text = data.installStudio
                tvStudioVersion.text = data.studioVersion
            }
        }
    }

    private fun showDeveloperInfoDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_developer_info)

        // Set dialog width to match parent
        val window = dialog.window
        window?.setLayout(
            android.view.WindowManager.LayoutParams.MATCH_PARENT,
            android.view.WindowManager.LayoutParams.WRAP_CONTENT
        )

        // Set close button click listener
        val btnClose = dialog.findViewById<Button>(R.id.btn_close_dialog)
        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }
}

